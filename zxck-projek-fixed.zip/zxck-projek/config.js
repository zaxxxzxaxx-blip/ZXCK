module.exports = {
  BOT_NAME: "ZXCK PROJEK",
  OWNER_NAME: "Owner",
  OWNER_NUMBER: "6287894002192", // format 62xxxxxxxxxx, tanpa + dan tanpa spasi
  PREFIX: ".",                   // awalan perintah, contoh: .menu
  USE_PAIRING_CODE: true,        // true = tautan pakai kode 8 digit, false = tautan pakai QR
  AUTO_READ: true,               // otomatis membaca pesan masuk
  AUTO_TYPING: false,            // tampil "mengetik..." saat membalas
  ANTI_LINK: false,              // hapus pesan berisi link grup di grup
  WELCOME_MESSAGE: true,         // sapa anggota baru
  WEB_PORT: 3000,                // port dashboard web
  WEB_HTTPS: true,               // aktifkan HTTPS di dashboard (butuh sertifikat, lihat README)
  TIMEZONE: "Asia/Jakarta",
};
