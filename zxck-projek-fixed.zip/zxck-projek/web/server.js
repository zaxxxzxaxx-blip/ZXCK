const express = require("express");
const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");
const chalk = require("chalk");
const config = require("../config");
const { getSettings, updateSettings } = require("../lib/settings");
const { ambilStats } = require("../lib/stats");
const { pastikanKredensial, buatSesi, sesiValid, hapusSesi } = require("../lib/auth");

function ambilCookie(req, nama) {
  const header = req.headers.cookie;
  if (!header) return null;
  for (const bagian of header.split(";")) {
    const idx = bagian.indexOf("=");
    if (idx === -1) continue;
    const k = bagian.slice(0, idx).trim();
    const v = bagian.slice(idx + 1).trim();
    if (k === nama) return decodeURIComponent(v);
  }
  return null;
}

function kirimNotifOwner(state, teks) {
  try {
    const s = getSettings();
    if (!s.NOTIFY_ON_LOGIN) return;
    if (!state.sock || !config.OWNER_NUMBER) return;
    state.sock.sendMessage(`${config.OWNER_NUMBER}@s.whatsapp.net`, { text: teks }).catch(() => {});
  } catch (_) {}
}

function jalankanWeb(state) {
  const kredensial = pastikanKredensial();
  if (kredensial._baruDibuat) {
    console.log(chalk.magenta(`\n🔐 Login dashboard dibuat otomatis (catat baik-baik!):`));
    console.log(chalk.bold.white(`   Username : ${kredensial.DASHBOARD_USERNAME}`));
    console.log(chalk.bold.white(`   Key      : ${kredensial.DASHBOARD_KEY}`));
    console.log(chalk.gray(`   Ganti kapan saja lewat WA: .setdashboarduser / .setdashboardkey\n`));
  }

  const app = express();
  app.use(express.json());
  const PUBLIC_DIR = path.join(__dirname, "..", "public");

  // === Aset & rute yang BOLEH diakses tanpa login (dibutuhkan halaman /login) ===
  app.get("/style.css", (req, res) => res.sendFile(path.join(PUBLIC_DIR, "style.css")));
  app.get("/menu-banner.png", (req, res) => res.sendFile(path.join(PUBLIC_DIR, "menu-banner.png")));
  app.get("/logo.svg", (req, res) => res.sendFile(path.join(PUBLIC_DIR, "logo.svg")));
  app.get("/login.js", (req, res) => res.sendFile(path.join(PUBLIC_DIR, "login.js")));
  app.get("/login", (req, res) => res.sendFile(path.join(PUBLIC_DIR, "login.html")));

  app.post("/api/login", (req, res) => {
    const s = getSettings();
    const { username, key } = req.body || {};
    const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").toString();
    if (!s.DASHBOARD_ENABLED) {
      return res.status(503).json({ error: "Dashboard sedang dimatikan oleh owner." });
    }
    if (username === s.DASHBOARD_USERNAME && key === s.DASHBOARD_KEY) {
      const token = buatSesi();
      res.setHeader("Set-Cookie", `zxck_sesi=${token}; HttpOnly; Path=/; Max-Age=${12 * 3600}; SameSite=Lax`);
      kirimNotifOwner(state, `🔓 *Login dashboard berhasil*\n🕒 ${new Date().toLocaleString("id-ID")}\n🌐 IP: ${ip}\n\nBukan kamu? Ganti key sekarang: .setdashboardkey [key_baru]`);
      return res.json({ ok: true });
    }
    kirimNotifOwner(state, `⚠️ *Percobaan login GAGAL* ke dashboard\n👤 Username dicoba: ${username || "-"}\n🕒 ${new Date().toLocaleString("id-ID")}\n🌐 IP: ${ip}`);
    return res.status(401).json({ error: "Username atau key salah." });
  });

  // === Mulai baris ini WAJIB LOGIN ===
  app.use((req, res, next) => {
    const s = getSettings();
    if (!s.DASHBOARD_ENABLED) {
      if (req.path.startsWith("/api/")) return res.status(503).json({ error: "Dashboard sedang dimatikan oleh owner." });
      return res.status(503).send(`<body style="background:#05060a;color:#c9a7ff;font-family:sans-serif;padding:60px;text-align:center">
        <h2>🔒 Dashboard sedang dimatikan oleh owner</h2>
        <p>Owner bisa menyalakannya lagi lewat WhatsApp: <code>.dashboardon</code></p></body>`);
    }
    const token = ambilCookie(req, "zxck_sesi");
    if (sesiValid(token)) return next();
    if (req.path.startsWith("/api/")) return res.status(401).json({ error: "Belum login." });
    return res.redirect("/login");
  });

  app.post("/api/logout", (req, res) => {
    hapusSesi(ambilCookie(req, "zxck_sesi"));
    res.setHeader("Set-Cookie", `zxck_sesi=; HttpOnly; Path=/; Max-Age=0`);
    res.json({ ok: true });
  });

  app.use(express.static(PUBLIC_DIR));

  app.get("/api/status", (req, res) => {
    res.json({
      nama: config.BOT_NAME,
      status: state.status,
      nomor: state.connectedNumber,
      qr: state.qrDataUrl,
      pairingCode: state.pairingCode,
    });
  });

  app.get("/api/settings", (req, res) => {
    res.json(getSettings());
  });

  app.post("/api/settings", (req, res) => {
    const diizinkan = [
      "PREFIX", "AUTO_READ", "AUTO_TYPING", "ANTI_LINK", "WELCOME_MESSAGE",
      "RESPOND_IN_GROUPS", "RESPOND_IN_PRIVATE", "SHOW_FULL_MENU_IN_GROUP",
    ];
    const perubahan = {};
    for (const k of diizinkan) {
      if (k in req.body) perubahan[k] = req.body[k];
    }
    const hasil = updateSettings(perubahan);
    res.json(hasil);
  });

  app.get("/api/stats", (req, res) => {
    res.json({
      ...ambilStats(),
      status: state.status,
      nomor: state.connectedNumber,
    });
  });

  // === Peninjau kode (read-only) ===
  // Daftar putih berkas yang boleh dilihat lewat browser — session/ (kredensial
  // WhatsApp) dan web/cert/ (kunci HTTPS) SENGAJA tidak pernah dimasukkan.
  const ROOT_DIR = path.join(__dirname, "..");
  const BERKAS_DIIZINKAN = [
    "index.js", "config.js", "package.json", "README.md",
    "lib/settings.js", "lib/anti-ban.js", "lib/connection.js", "lib/stats.js", "lib/chats.js", "lib/media.js", "lib/auth.js",
    "commands/index.js",
    "web/server.js",
    "public/index.html", "public/app.js", "public/style.css",
    "public/settings.html", "public/settings.js",
    "public/stats.html", "public/stats.js",
    "public/code.html", "public/code.js",
    "public/login.html", "public/login.js",
  ];

  app.get("/api/code/list", (req, res) => {
    const daftar = BERKAS_DIIZINKAN.filter((rel) => fs.existsSync(path.join(ROOT_DIR, rel)));
    res.json({ files: daftar });
  });

  app.get("/api/code/file", (req, res) => {
    const rel = req.query.path;
    if (!rel || !BERKAS_DIIZINKAN.includes(rel)) {
      return res.status(404).json({ error: "Berkas tidak ditemukan atau tidak diizinkan dilihat." });
    }
    const target = path.resolve(ROOT_DIR, rel);
    if (!target.startsWith(ROOT_DIR)) {
      return res.status(400).json({ error: "Path tidak valid." });
    }
    fs.readFile(target, "utf-8", (err, isi) => {
      if (err) return res.status(404).json({ error: "Gagal membaca berkas." });
      res.json({ path: rel, content: isi });
    });
  });

  app.get("/", (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, "index.html"));
  });
  app.get("/settings", (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, "settings.html"));
  });
  app.get("/stats", (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, "stats.html"));
  });
  app.get("/code", (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, "code.html"));
  });

  const CERT_DIR = path.join(__dirname, "cert");
  const keyPath = path.join(CERT_DIR, "key.pem");
  const certPath = path.join(CERT_DIR, "cert.pem");

  http.createServer(app).listen(config.WEB_PORT, () => {
    console.log(`🌐 Dashboard HTTP aktif di http://localhost:${config.WEB_PORT}`);
  });

  if (config.WEB_HTTPS) {
    if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
      const opsi = { key: fs.readFileSync(keyPath), cert: fs.readFileSync(certPath) };
      const portHttps = config.WEB_PORT + 1;
      https.createServer(opsi, app).listen(portHttps, () => {
        console.log(`🔒 Dashboard HTTPS aktif di https://localhost:${portHttps}`);
      });
    } else {
      console.log(`⚠️  Sertifikat HTTPS belum ada di web/cert/. Jalankan perintah di README untuk membuatnya.`);
      console.log(`   Sementara dashboard hanya berjalan lewat HTTP.`);
    }
  }
}

module.exports = { jalankanWeb };
