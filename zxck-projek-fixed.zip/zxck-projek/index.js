const chalk = require("chalk");
const figlet = require("figlet");
const config = require("./config");
const { mulaiKoneksi, state } = require("./lib/connection");
const { tanganiPesan } = require("./commands/index");
const { jalankanWeb } = require("./web/server");
const { apakahPesanBot } = require("./lib/anti-ban");
const { getSettings } = require("./lib/settings");
const { catatPesanMasuk } = require("./lib/stats");

console.log(chalk.cyan(figlet.textSync("ZXCK PROJEK", { horizontalLayout: "full" })));
console.log(chalk.gray("Bot WhatsApp pribadi — Baileys + Termux\n"));

// Dipasang ke SETIAP socket baru (koneksi pertama maupun tiap kali bot
// menyambung ulang secara otomatis) lewat lib/connection.js. Ini yang
// memastikan bot tetap bisa dichat di pribadi maupun grup setelah
// reconnect, bukan cuma di koneksi pertama.
function pasangHandler(sock) {
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const m = messages[0];
    if (!m.message) return;

    const settings = getSettings();
    const jid = m.key.remoteJid;
    if (!jid || jid === "status@broadcast") return;
    const isGrup = jid.endsWith("@g.us");

    // Pesan dari device sendiri (fromMe: true) bisa berarti dua hal:
    // 1) balasan otomatis yang tadi DIKIRIM oleh bot -> harus diabaikan
    // 2) pesan yang benar-benar DIKETIK owner manual dari HP -> harus diproses
    // Bedanya dicek dari ID pesan: kalau ID itu ada di daftar "pesan milik bot",
    // berarti itu balasan bot sendiri, bukan ketikan owner.
    if (m.key.fromMe && apakahPesanBot(m.key.id)) return;

    // Saklar on/off dari dashboard web
    if (isGrup && !settings.RESPOND_IN_GROUPS) return;
    if (!isGrup && !settings.RESPOND_IN_PRIVATE) return;

    catatPesanMasuk();

    if (settings.AUTO_READ) {
      sock.readMessages([m.key]).catch(() => {});
    }
    if (settings.AUTO_TYPING) {
      sock.sendPresenceUpdate("composing", jid).catch(() => {});
    }

    await tanganiPesan(sock, m);
  });

  sock.ev.on("group-participants.update", async (ev) => {
    const settings = getSettings();
    if (!settings.WELCOME_MESSAGE || ev.action !== "add") return;
    try {
      const meta = await sock.groupMetadata(ev.id);
      for (const peserta of ev.participants) {
        await sock.sendMessage(ev.id, {
          text: `👋 Selamat datang @${peserta.split("@")[0]} di grup *${meta.subject}*!`,
          mentions: [peserta],
        });
      }
    } catch (e) {
      console.error("Gagal kirim pesan selamat datang:", e.message);
    }
  });
}

async function main() {
  await mulaiKoneksi(pasangHandler);

  // Dashboard web (QR/pairing code juga bisa dilihat lewat browser, real-time)
  jalankanWeb(state);
}

main().catch((e) => console.error("Kesalahan fatal:", e));
