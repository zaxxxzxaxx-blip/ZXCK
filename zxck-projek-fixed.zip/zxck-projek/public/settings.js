const DAFTAR_TOGGLE = [
  { key: "RESPOND_IN_GROUPS", label: "Bot merespon di grup", desc: "Kalau dimatikan, bot diam total di semua grup — tidak balas apapun." },
  { key: "RESPOND_IN_PRIVATE", label: "Bot merespon di chat pribadi", desc: "Kalau dimatikan, bot diam di chat pribadi (personal)." },
  { key: "AUTO_READ", label: "Otomatis membaca pesan (centang biru)", desc: "" },
  { key: "AUTO_TYPING", label: "Tampilkan status 'mengetik...'", desc: "Sebelum bot membalas pesan." },
  { key: "ANTI_LINK", label: "Anti-link di grup", desc: "Hapus pesan yang berisi link grup WhatsApp." },
  { key: "WELCOME_MESSAGE", label: "Sapaan anggota baru", desc: "Bot menyapa otomatis saat ada anggota baru masuk grup." },
];

let settingsSaatIni = {};

function buatBarisToggle(item, nilai) {
  const div = document.createElement("div");
  div.className = "baris-toggle";
  div.innerHTML = `
    <div class="teks-toggle">
      <div class="label-toggle">${item.label}</div>
      ${item.desc ? `<div class="desc-toggle">${item.desc}</div>` : ""}
    </div>
    <label class="switch">
      <input type="checkbox" data-key="${item.key}" ${nilai ? "checked" : ""} />
      <span class="slider"></span>
    </label>
  `;
  return div;
}

async function muatSettings() {
  const res = await fetch("/api/settings");
  if (res.status === 401) return (window.location.href = "/login");
  settingsSaatIni = await res.json();
  const wadah = document.getElementById("daftar-toggle");
  wadah.innerHTML = "";
  DAFTAR_TOGGLE.forEach((item) => {
    wadah.appendChild(buatBarisToggle(item, settingsSaatIni[item.key]));
  });
}

async function simpanSettings() {
  const inputs = document.querySelectorAll("#daftar-toggle input[type=checkbox]");
  const perubahan = {};
  inputs.forEach((inp) => { perubahan[inp.dataset.key] = inp.checked; });

  const pesan = document.getElementById("pesan-status");
  pesan.textContent = "Menyimpan...";
  try {
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(perubahan),
    });
    if (res.ok) {
      pesan.textContent = "✅ Tersimpan! Pengaturan langsung aktif.";
      setTimeout(() => (pesan.textContent = ""), 3000);
    } else {
      pesan.textContent = "❌ Gagal menyimpan.";
    }
  } catch (e) {
    pesan.textContent = "❌ Gagal menghubungi server.";
  }
}

document.getElementById("btn-simpan").addEventListener("click", simpanSettings);
muatSettings();
