function escapeHtml(teks) {
  return teks
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

async function muatDaftarFile() {
  const wadah = document.getElementById("daftar-file");
  try {
    const res = await fetch("/api/code/list");
    if (res.status === 401) return (window.location.href = "/login");
    const data = await res.json();
    wadah.innerHTML = "";
    data.files.forEach((rel) => {
      const btn = document.createElement("button");
      btn.className = "btn-file";
      btn.textContent = rel;
      btn.addEventListener("click", () => bukaFile(rel));
      wadah.appendChild(btn);
    });
  } catch (e) {
    wadah.innerHTML = "<div class='info'>Gagal memuat daftar berkas.</div>";
  }
}

async function bukaFile(rel) {
  const pratinjau = document.getElementById("pratinjau");
  const judul = document.getElementById("pratinjau-judul");
  const isi = document.getElementById("pratinjau-isi");
  judul.textContent = rel;
  isi.textContent = "Memuat...";
  pratinjau.style.display = "block";
  pratinjau.scrollIntoView({ behavior: "smooth" });
  try {
    const res = await fetch("/api/code/file?path=" + encodeURIComponent(rel));
    const data = await res.json();
    if (data.error) {
      isi.textContent = data.error;
    } else {
      isi.textContent = data.content;
    }
  } catch (e) {
    isi.textContent = "Gagal memuat isi berkas.";
  }
}

muatDaftarFile();
