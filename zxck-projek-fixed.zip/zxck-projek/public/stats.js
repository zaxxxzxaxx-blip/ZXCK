function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const d = Math.floor(s % 60);
  return `${h}j ${m}m ${d}d`;
}

function kartuStat(label, nilai) {
  const div = document.createElement("div");
  div.className = "kotak-stat";
  div.innerHTML = `<div class="nilai-stat">${nilai}</div><div class="label-stat">${label}</div>`;
  return div;
}

async function muatStats() {
  try {
    const res = await fetch("/api/stats");
    if (res.status === 401) return (window.location.href = "/login");
    const data = await res.json();

    const grid = document.getElementById("grid-stat");
    grid.innerHTML = "";
    grid.appendChild(kartuStat("Status Koneksi", data.status === "connected" ? "🟢 Aktif" : "🔴 " + data.status));
    grid.appendChild(kartuStat("Nomor Tertaut", data.nomor || "-"));
    grid.appendChild(kartuStat("Lama Menyala", formatUptime(data.uptimeMs)));
    grid.appendChild(kartuStat("Total Pesan Masuk", data.totalPesanMasuk));
    grid.appendChild(kartuStat("Total Perintah Dijalankan", data.totalPerintahDijalankan));
    grid.appendChild(kartuStat("Pemakaian Memori", data.memoriMB + " MB"));

    const daftar = document.getElementById("daftar-perintah");
    daftar.innerHTML = "";
    if (!data.perintahTerbanyak || data.perintahTerbanyak.length === 0) {
      daftar.innerHTML = "<div class='info'>Belum ada perintah yang dijalankan.</div>";
    } else {
      data.perintahTerbanyak.forEach(([nama, jumlah]) => {
        const baris = document.createElement("div");
        baris.className = "baris-perintah";
        baris.innerHTML = `<span>.${nama}</span><span class="badge-jumlah">${jumlah}x</span>`;
        daftar.appendChild(baris);
      });
    }
  } catch (e) {
    document.getElementById("grid-stat").innerHTML = "<div class='info'>Gagal memuat data performa.</div>";
  }
}

muatStats();
setInterval(muatStats, 4000);
