async function perbarui() {
  try {
    const res = await fetch("/api/status");
    const data = await res.json();

    const statusEl = document.getElementById("status");
    const qrWrap = document.getElementById("qr-wrap");
    const pairingWrap = document.getElementById("pairing-wrap");
    const infoText = document.getElementById("info-text");
    const nomorText = document.getElementById("nomor-text");

    statusEl.className = "status-pill " + (data.status === "connected" ? "connected" : data.status === "terputus" ? "terputus" : "");

    const label = {
      menunggu: "Menunggu...",
      qr: "Menunggu scan QR",
      pairing: "Menunggu kode pasangan",
      connected: "Tertaut & Aktif",
      terputus: "Terputus",
    };
    statusEl.textContent = label[data.status] || data.status;

    qrWrap.innerHTML = "";
    pairingWrap.innerHTML = "";

    if (data.status === "qr" && data.qr) {
      const img = document.createElement("img");
      img.src = data.qr;
      qrWrap.appendChild(img);
      infoText.textContent = "Buka WhatsApp > Perangkat Tertaut > Tautkan Perangkat, lalu scan kode di atas.";
    } else if (data.status === "pairing" && data.pairingCode) {
      const kode = document.createElement("div");
      kode.className = "kode-pairing";
      kode.textContent = data.pairingCode;
      pairingWrap.appendChild(kode);
      infoText.textContent = "Buka WhatsApp > Perangkat Tertaut > Tautkan dengan nomor telepon, lalu masukkan kode di atas.";
    } else if (data.status === "connected") {
      infoText.textContent = "Bot sudah tertaut dan siap digunakan.";
      nomorText.textContent = data.nomor ? "Nomor: " + data.nomor : "";
    } else {
      infoText.textContent = "Menyiapkan koneksi ke WhatsApp...";
    }
  } catch (e) {
    document.getElementById("info-text").textContent = "Gagal menghubungi server.";
  }
}

perbarui();
setInterval(perbarui, 2500);

document.getElementById("btn-logout")?.addEventListener("click", async (e) => {
  e.preventDefault();
  try { await fetch("/api/logout", { method: "POST" }); } catch (_) {}
  window.location.href = "/login";
});
