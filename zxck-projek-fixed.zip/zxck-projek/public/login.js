document.getElementById("form-login").addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("username").value.trim();
  const key = document.getElementById("key").value;
  const pesan = document.getElementById("pesan-error");
  pesan.textContent = "";

  try {
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, key }),
    });
    if (res.ok) {
      window.location.href = "/";
    } else {
      const data = await res.json().catch(() => ({}));
      pesan.textContent = "❌ " + (data.error || "Login gagal.");
    }
  } catch (e) {
    pesan.textContent = "❌ Gagal menghubungi server.";
  }
});
