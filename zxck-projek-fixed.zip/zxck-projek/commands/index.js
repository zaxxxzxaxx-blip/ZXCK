const axios = require("axios");
const moment = require("moment-timezone");
const fs = require("fs");
const path = require("path");
const config = require("../config");
const { kirimAman } = require("../lib/anti-ban");
const { getSettings, updateSettings } = require("../lib/settings");
const { catatPerintah } = require("../lib/stats");
const { catatChat, ambilSemuaChat } = require("../lib/chats");
const { buatStiker, stikerKeGambar } = require("../lib/media");

const BANNER_PATH = path.join(__dirname, "..", "assets", "menu-banner.png");
const PERINTAH_VALID = new Set([
  "menu","help","ping","owner","runtime","about","jam","tanggal","status",
  "kick","add","promote","demote","grouplink","revoke","tagall","hidetag",
  "setname","setdesc","mutegroup","unmutegroup","antilink","welcome","delete","groupinfo",
  "upper","lower","reverse","capital","count","encode","decode","sticker","toimage",
  "dice","coin","quote","truth","dare","jodoh","pilih","rate","tebakangka","nyerah",
  "calc","qrcode","shortlink","cuaca","kurs","translate","suhu","bmi","pw","hitungmundur",
  "broadcast","setbio","block","unblock","restart","join",
  "dashboardon","dashboardoff","setdashboarduser","setdashboardkey","loginnotif","dashboardinfo",
]);

const mulaiWaktu = Date.now();

// State game tebak angka aktif per-chat (jid -> { angka, percobaan })
const gameTebak = new Map();

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const d = Math.floor(s % 60);
  return `${h}j ${m}m ${d}d`;
}

const DAFTAR_MENU = `
╭─❖ *${config.BOT_NAME}* ❖─╮

📌 *UMUM*
.menu / .help — daftar perintah
.ping — cek kecepatan bot
.owner — info pemilik bot
.runtime — lama bot menyala
.about — tentang bot
.jam — jam saat ini
.tanggal — tanggal hari ini
.status — status koneksi

🛡️ *ADMIN GRUP*
.kick @user — keluarkan anggota
.add 62xxx — tambah anggota
.promote @user — jadikan admin
.demote @user — turunkan admin
.grouplink — ambil link grup
.revoke — reset link grup
.tagall — tag semua anggota
.hidetag [teks] — tag tersembunyi
.setname [nama] — ganti nama grup
.setdesc [teks] — ganti deskripsi grup
.mutegroup — kunci grup (admin only)
.unmutegroup — buka kunci grup
.antilink on/off — filter link grup
.welcome on/off — sapaan anggota baru
.delete — hapus pesan (reply)
.groupinfo — info grup

🔤 *TEKS & KONVERSI*
.upper [teks] — huruf besar
.lower [teks] — huruf kecil
.reverse [teks] — balik teks
.capital [teks] — kapital tiap kata
.count [teks] — hitung kata/karakter
.encode [teks] — encode base64
.decode [teks] — decode base64
.sticker — gambar/video ke stiker (reply/caption)
.toimage — stiker ke gambar (reply)

🎲 *HIBURAN*
.dice — lempar dadu
.coin — lempar koin
.quote — kata bijak acak
.truth — pertanyaan truth
.dare — tantangan dare
.jodoh @user1 @user2 — persenan jodoh iseng
.pilih a|b|c — pilih acak dari opsi
.rate [teks] — nilai acak 1-100
.tebakangka — mulai game tebak angka (1-100), ketik angka langsung untuk menebak
.nyerah — menyerah dari game tebak angka

🧮 *UTILITAS*
.calc [ekspresi] — kalkulator
.qrcode [teks] — buat kode QR
.shortlink [url] — perpendek tautan
.cuaca [kota] — cek cuaca
.kurs [dari] [ke] [jumlah] — konversi mata uang
.translate [kode] [teks] — terjemahan
.suhu [celsius] — konversi ke fahrenheit/kelvin
.bmi [berat] [tinggi] — hitung BMI
.pw [panjang] — buat password acak
.hitungmundur [detik] — pasang pengingat

👑 *OWNER*
.broadcast [teks] — kirim ke semua chat aktif bot
.setbio [teks] — ganti bio WhatsApp
.block @user — blokir kontak
.unblock @user — buka blokir
.restart — mulai ulang bot
.join [link] — gabung grup via link
.dashboardon / .dashboardoff — nyala/matikan dashboard web
.setdashboarduser [nama] — ganti username login dashboard
.setdashboardkey [key] — ganti key login dashboard
.loginnotif on/off — notifikasi WA tiap ada yang login dashboard
.dashboardinfo — lihat username & key dashboard saat ini

╰──────────────╯
Prefix: "${config.PREFIX}" | Ketik perintah tanpa tanda kurung
`.trim();

const KATA_BIJAK = [
  "Kegagalan hanyalah kesempatan untuk memulai lagi dengan lebih cerdas.",
  "Jangan tunggu waktu yang tepat, ciptakan waktu yang tepat.",
  "Langkah kecil yang konsisten mengalahkan langkah besar yang tidak pernah dimulai.",
  "Belajar hari ini, memimpin di masa depan.",
  "Kesabaran adalah kunci dari segala kemudahan.",
];
const DAFTAR_TRUTH = [
  "Apa hal paling memalukan yang pernah kamu lakukan?",
  "Siapa gebetan pertamamu?",
  "Apa rahasia yang belum pernah kamu ceritakan ke siapa pun?",
];
const DAFTAR_DARE = [
  "Kirim voice note sambil bernyanyi 10 detik!",
  "Ganti foto profil dengan foto lucu selama 1 jam.",
  "Tulis pantun receh sekarang juga.",
];

function ambilTeks(m) {
  return (
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    ""
  );
}

async function tanganiPesan(sock, m) {
  try {
    const settings = getSettings();
    const jid = m.key.remoteJid;
    const teksAsli = ambilTeks(m);
    catatChat(jid); // dicatat untuk fitur .broadcast (khusus owner)

    // Game tebak angka aktif: tebakan diketik LANGSUNG tanpa prefix
    if (gameTebak.has(jid) && /^\d+$/.test(teksAsli.trim())) {
      const g = gameTebak.get(jid);
      const tebakan = parseInt(teksAsli.trim(), 10);
      g.percobaan++;
      if (tebakan === g.angka) {
        gameTebak.delete(jid);
        return kirimAman(sock, jid, { text: `🎉 Benar! Angkanya *${g.angka}*. Ditebak dalam ${g.percobaan}x percobaan.` }, { quoted: m });
      } else if (g.percobaan >= 15) {
        gameTebak.delete(jid);
        return kirimAman(sock, jid, { text: `😵 Kesempatan habis (15x)! Angkanya adalah *${g.angka}*.` }, { quoted: m });
      } else {
        return kirimAman(sock, jid, { text: (tebakan < g.angka ? "⬆️ Lebih besar!" : "⬇️ Lebih kecil!") + ` (percobaan ke-${g.percobaan})` }, { quoted: m });
      }
    }

    const prefix = settings.PREFIX || config.PREFIX;
    if (!teksAsli.startsWith(prefix)) return;

    const tanpaPrefix = teksAsli.slice(prefix.length).trim();
    const [cmdMentah, ...argArr] = tanpaPrefix.split(" ");
    const cmd = cmdMentah.toLowerCase();
    const teks = argArr.join(" ");
    const isGrup = jid.endsWith("@g.us");

    // Deteksi owner: pesan asli dari HP owner sendiri (fromMe, sudah
    // dipastikan bukan balasan bot sendiri di index.js) ATAU nomor pengirim
    // cocok dengan OWNER_NUMBER di config — supaya owner tetap dikenali
    // meski chat dari grup atau nomor lain yang tertaut.
    const senderJid = isGrup ? (m.key.participant || jid) : jid;
    const senderNumber = senderJid?.split("@")[0];
    const isOwner = m.key.fromMe || senderNumber === config.OWNER_NUMBER;

    if (PERINTAH_VALID.has(cmd)) catatPerintah(cmd);

    const balas = (isi) => kirimAman(sock, jid, { text: isi }, { quoted: m });

    switch (cmd) {
      // ==== UMUM ====
      case "menu":
      case "help": {
        // Owner selalu dapat menu teks lengkap langsung di chat manapun.
        // User biasa dapat tampilan bergambar (banner) + menu di caption.
        // Di grup, daftar lengkap TIDAK ditampilkan ke publik — bot balas
        // singkat di grup dan mengirim menu lengkap lewat chat pribadi (DM).
        const kirimMenuKe = async (tujuanJid, opsiQuoted) => {
          try {
            if (isOwner) {
              await kirimAman(sock, tujuanJid, { text: DAFTAR_MENU }, opsiQuoted);
            } else {
              await kirimAman(
                sock,
                tujuanJid,
                { image: fs.readFileSync(BANNER_PATH), caption: DAFTAR_MENU },
                opsiQuoted
              );
            }
          } catch (e) {
            await kirimAman(sock, tujuanJid, { text: DAFTAR_MENU }, opsiQuoted).catch(() => {});
          }
        };

        if (isGrup) {
          await balas(isOwner ? "📋 Menu dikirim ke chat pribadimu." : "📋 Menu lengkap dikirim lewat chat pribadi ya, cek DM! 😊");
          await kirimMenuKe(senderJid).catch(() => {
            // gagal DM (belum pernah chat bot secara pribadi) -> diamkan, sudah dikasih tahu di grup
          });
          return;
        }
        return kirimMenuKe(jid, { quoted: m });
      }

      case "ping": {
        const mulai = Date.now();
        const kirim = await balas("🏓 Menghitung...");
        const jarak = Date.now() - mulai;
        return kirimAman(sock, jid, { text: `🏓 Pong! ${jarak}ms`, edit: kirim?.key }).catch(() => {});
      }

      case "owner":
        return balas(`👑 Owner: ${config.OWNER_NAME}\n📱 Nomor: wa.me/${config.OWNER_NUMBER}`);

      case "runtime":
        return balas(`⏱️ Bot sudah menyala: ${formatUptime(Date.now() - mulaiWaktu)}`);

      case "about":
        return balas(`✨ ${config.BOT_NAME}\nBot WhatsApp pribadi berbasis Baileys, dijalankan lewat Termux.`);

      case "jam":
        return balas(`🕒 Jam sekarang: ${moment().tz(config.TIMEZONE).format("HH:mm:ss")}`);

      case "tanggal":
        return balas(`📅 Hari ini: ${moment().tz(config.TIMEZONE).format("dddd, D MMMM YYYY")}`);

      case "status":
        return balas(`🔌 Status koneksi: Tersambung\n📱 Nomor bot: ${sock.user?.id?.split(":")[0]}`);

      // ==== ADMIN GRUP ====
      case "kick": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        const target = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!target) return balas("Tag anggota yang ingin dikeluarkan.");
        await sock.groupParticipantsUpdate(jid, [target], "remove");
        return balas("✅ Anggota dikeluarkan.");
      }
      case "add": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        if (!teks) return balas("Sertakan nomor. Contoh: .add 628xxxxxxxxxx");
        const nomorBersih = teks.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await sock.groupParticipantsUpdate(jid, [nomorBersih], "add");
        return balas("✅ Berhasil menambahkan anggota.");
      }
      case "promote": {
        const target = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!isGrup || !target) return balas("Tag anggota yang ingin dijadikan admin.");
        await sock.groupParticipantsUpdate(jid, [target], "promote");
        return balas("✅ Berhasil menjadikan admin.");
      }
      case "demote": {
        const target = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!isGrup || !target) return balas("Tag anggota yang ingin diturunkan.");
        await sock.groupParticipantsUpdate(jid, [target], "demote");
        return balas("✅ Berhasil menurunkan admin.");
      }
      case "grouplink": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        const kode = await sock.groupInviteCode(jid);
        return balas(`🔗 https://chat.whatsapp.com/${kode}`);
      }
      case "revoke": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        await sock.groupRevokeInvite(jid);
        return balas("✅ Link grup berhasil direset.");
      }
      case "tagall": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        const meta = await sock.groupMetadata(jid);
        const semua = meta.participants.map((p) => p.id);
        const teksTag = semua.map((id) => `@${id.split("@")[0]}`).join(" ");
        return kirimAman(sock, jid, { text: teksTag, mentions: semua });
      }
      case "hidetag": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        const meta = await sock.groupMetadata(jid);
        const semua = meta.participants.map((p) => p.id);
        return kirimAman(sock, jid, { text: teks || "​", mentions: semua });
      }
      case "setname": {
        if (!isGrup || !teks) return balas("Contoh: .setname Nama Grup Baru");
        await sock.groupUpdateSubject(jid, teks);
        return balas("✅ Nama grup diganti.");
      }
      case "setdesc": {
        if (!isGrup || !teks) return balas("Contoh: .setdesc Deskripsi baru grup");
        await sock.groupUpdateDescription(jid, teks);
        return balas("✅ Deskripsi grup diganti.");
      }
      case "mutegroup": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        await sock.groupSettingUpdate(jid, "announcement");
        return balas("🔒 Grup dikunci, hanya admin yang bisa kirim pesan.");
      }
      case "unmutegroup": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        await sock.groupSettingUpdate(jid, "not_announcement");
        return balas("🔓 Grup dibuka, semua anggota bisa kirim pesan.");
      }
      case "antilink": {
        if (!isOwner) return balas("Hanya owner yang boleh mengubah pengaturan ini.");
        if (teks === "on" || teks === "off") {
          updateSettings({ ANTI_LINK: teks === "on" });
          return balas(`Fitur antilink: ${teks === "on" ? "diaktifkan ✅" : "dimatikan ❌"}`);
        }
        return balas("Gunakan .antilink on / .antilink off (bisa juga lewat dashboard web > Pengaturan)");
      }
      case "welcome": {
        if (!isOwner) return balas("Hanya owner yang boleh mengubah pengaturan ini.");
        if (teks === "on" || teks === "off") {
          updateSettings({ WELCOME_MESSAGE: teks === "on" });
          return balas(`Fitur welcome: ${teks === "on" ? "diaktifkan ✅" : "dimatikan ❌"}`);
        }
        return balas("Gunakan .welcome on / .welcome off (bisa juga lewat dashboard web > Pengaturan)");
      }
      case "delete": {
        const ctx = m.message?.extendedTextMessage?.contextInfo;
        if (!ctx?.stanzaId) return balas("Reply pesan yang mau dihapus dengan perintah ini.");
        await sock.sendMessage(jid, { delete: { remoteJid: jid, fromMe: false, id: ctx.stanzaId, participant: ctx.participant } });
        return;
      }
      case "groupinfo": {
        if (!isGrup) return balas("Perintah ini hanya untuk grup.");
        const meta = await sock.groupMetadata(jid);
        return balas(`👥 *${meta.subject}*\nAnggota: ${meta.participants.length}\nID: ${meta.id}\nDeskripsi: ${meta.desc || "-"}`);
      }

      // ==== TEKS & KONVERSI ====
      case "upper":
        return balas(teks.toUpperCase() || "Sertakan teksnya.");
      case "lower":
        return balas(teks.toLowerCase() || "Sertakan teksnya.");
      case "reverse":
        return balas(teks.split("").reverse().join("") || "Sertakan teksnya.");
      case "capital":
        return balas(teks.replace(/\b\w/g, (c) => c.toUpperCase()) || "Sertakan teksnya.");
      case "count":
        return balas(`Karakter: ${teks.length}\nKata: ${teks.trim() ? teks.trim().split(/\s+/).length : 0}`);
      case "encode":
        return balas(Buffer.from(teks).toString("base64") || "Sertakan teksnya.");
      case "decode":
        try { return balas(Buffer.from(teks, "base64").toString("utf-8")); }
        catch { return balas("Teks base64 tidak valid."); }
      case "sticker": {
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const sumber = quoted?.imageMessage ? quoted.imageMessage
          : quoted?.videoMessage ? quoted.videoMessage
          : m.message?.imageMessage ? m.message.imageMessage
          : m.message?.videoMessage ? m.message.videoMessage
          : null;
        const tipe = (quoted?.imageMessage || m.message?.imageMessage) ? "image" : "video";
        if (!sumber) return balas("Reply (atau kirim langsung dengan caption) gambar/video pendek dengan perintah .sticker");
        try {
          const buffer = await buatStiker(sumber, tipe);
          return kirimAman(sock, jid, { sticker: buffer }, { quoted: m });
        } catch (e) {
          return balas("❌ Gagal membuat stiker: " + e.message);
        }
      }
      case "toimage": {
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted?.stickerMessage) return balas("Reply stiker dengan perintah .toimage untuk mengubahnya jadi gambar.");
        try {
          const buffer = await stikerKeGambar(quoted.stickerMessage);
          return kirimAman(sock, jid, { image: buffer, caption: "✅ Berhasil diubah ke gambar." }, { quoted: m });
        } catch (e) {
          return balas("❌ Gagal mengubah stiker: " + e.message);
        }
      }

      // ==== HIBURAN ====
      case "dice":
        return balas(`🎲 Hasil dadu: ${Math.ceil(Math.random() * 6)}`);
      case "coin":
        return balas(`🪙 Hasil koin: ${Math.random() < 0.5 ? "Kepala" : "Ekor"}`);
      case "quote":
        return balas(`💬 "${KATA_BIJAK[Math.floor(Math.random() * KATA_BIJAK.length)]}"`);
      case "truth":
        return balas(`❓ ${DAFTAR_TRUTH[Math.floor(Math.random() * DAFTAR_TRUTH.length)]}`);
      case "dare":
        return balas(`🔥 ${DAFTAR_DARE[Math.floor(Math.random() * DAFTAR_DARE.length)]}`);
      case "jodoh": {
        const mentions = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (mentions.length < 2) return balas("Tag 2 orang. Contoh: .jodoh @a @b");
        return balas(`💞 Persentase jodoh: ${Math.floor(Math.random() * 100)}% (cuma iseng-iseng ya!)`);
      }
      case "pilih": {
        const opsi = teks.split("|").map((s) => s.trim()).filter(Boolean);
        if (opsi.length < 2) return balas("Pisahkan opsi dengan | . Contoh: .pilih makan|tidur|belajar");
        return balas(`🎯 Pilihan: ${opsi[Math.floor(Math.random() * opsi.length)]}`);
      }
      case "rate":
        return balas(`⭐ Nilai untuk "${teks || "-"}": ${Math.floor(Math.random() * 100) + 1}/100`);
      case "tebakangka": {
        if (gameTebak.has(jid)) return balas("🎮 Game sudah berjalan di chat ini, langsung ketik angka tebakanmu (1-100).");
        gameTebak.set(jid, { angka: Math.floor(Math.random() * 100) + 1, percobaan: 0 });
        return balas("🎮 Aku sudah pikirkan angka 1-100! Ketik angkanya langsung di chat (tanpa titik/prefix) untuk menebak. Ketik .nyerah untuk berhenti.");
      }
      case "nyerah": {
        if (!gameTebak.has(jid)) return balas("Tidak ada game tebak angka yang sedang berjalan di chat ini.");
        const g = gameTebak.get(jid);
        gameTebak.delete(jid);
        return balas(`🏳️ Menyerah! Angkanya adalah *${g.angka}*.`);
      }

      // ==== UTILITAS ====
      case "calc": {
        try {
          if (!/^[0-9+\-*/().\s%]+$/.test(teks)) return balas("Hanya boleh angka dan operator matematika.");
          // eslint-disable-next-line no-eval
          const hasil = eval(teks);
          return balas(`🧮 Hasil: ${hasil}`);
        } catch { return balas("Ekspresi tidak valid."); }
      }
      case "qrcode": {
        if (!teks) return balas("Sertakan teks/link. Contoh: .qrcode https://wa.me");
        const QRCode = require("qrcode");
        const buffer = await QRCode.toBuffer(teks);
        return kirimAman(sock, jid, { image: buffer, caption: `QR untuk: ${teks}` });
      }
      case "shortlink": {
        if (!teks) return balas("Sertakan URL. Contoh: .shortlink https://contoh.com");
        try {
          const res = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(teks)}`);
          return balas(`🔗 ${res.data}`);
        } catch { return balas("Gagal memperpendek link, coba lagi nanti."); }
      }
      case "cuaca": {
        if (!teks) return balas("Sertakan nama kota. Contoh: .cuaca Jakarta");
        try {
          const geo = await axios.get(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(teks)}&count=1`);
          const lokasi = geo.data?.results?.[0];
          if (!lokasi) return balas("Kota tidak ditemukan.");
          const cuaca = await axios.get(`https://api.open-meteo.com/v1/forecast?latitude=${lokasi.latitude}&longitude=${lokasi.longitude}&current_weather=true`);
          const c = cuaca.data.current_weather;
          return balas(`🌤️ Cuaca ${lokasi.name}:\nSuhu: ${c.temperature}°C\nAngin: ${c.windspeed} km/j`);
        } catch { return balas("Gagal mengambil data cuaca, coba lagi nanti."); }
      }
      case "kurs": {
        const [dari, ke, jumlah] = teks.split(" ");
        if (!dari || !ke) return balas("Contoh: .kurs USD IDR 10");
        try {
          const res = await axios.get(`https://api.exchangerate-api.com/v4/latest/${dari.toUpperCase()}`);
          const rate = res.data.rates[ke.toUpperCase()];
          if (!rate) return balas("Kode mata uang tidak ditemukan.");
          const total = (parseFloat(jumlah) || 1) * rate;
          return balas(`💱 ${jumlah || 1} ${dari.toUpperCase()} = ${total.toFixed(2)} ${ke.toUpperCase()}`);
        } catch { return balas("Gagal mengambil kurs, coba lagi nanti."); }
      }
      case "translate": {
        const [kode, ...isiArr] = argArr;
        const isi = isiArr.join(" ");
        if (!kode || !isi) return balas("Contoh: .translate en Selamat pagi");
        try {
          const res = await axios.get(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(isi)}&langpair=id|${kode}`);
          return balas(`🌐 ${res.data.responseData.translatedText}`);
        } catch { return balas("Gagal menerjemahkan, coba lagi nanti."); }
      }
      case "suhu": {
        const c = parseFloat(teks);
        if (isNaN(c)) return balas("Contoh: .suhu 30");
        return balas(`🌡️ ${c}°C = ${(c * 9/5 + 32).toFixed(1)}°F = ${(c + 273.15).toFixed(1)}K`);
      }
      case "bmi": {
        const [berat, tinggi] = teks.split(" ").map(Number);
        if (!berat || !tinggi) return balas("Contoh: .bmi 60 1.7 (kg dan meter)");
        const bmi = berat / (tinggi * tinggi);
        return balas(`⚖️ BMI kamu: ${bmi.toFixed(1)}`);
      }
      case "pw": {
        const panjang = Math.min(parseInt(teks) || 12, 64);
        const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";
        let pw = "";
        for (let i = 0; i < panjang; i++) pw += chars[Math.floor(Math.random() * chars.length)];
        return balas(`🔑 Password: ${pw}`);
      }
      case "hitungmundur": {
        const detik = parseInt(teks, 10);
        if (!detik || detik <= 0 || detik > 3600) return balas("Contoh: .hitungmundur 60 (dalam detik, maksimal 3600)");
        await balas(`⏳ Oke, aku akan mengingatkan lagi dalam ${detik} detik.`);
        setTimeout(() => {
          kirimAman(sock, jid, { text: `⏰ Waktu habis! Ini pengingat yang kamu pasang ${detik} detik lalu.` }, { quoted: m }).catch(() => {});
        }, detik * 1000);
        return;
      }

      // ==== OWNER (khusus owner, user biasa akan ditolak) ====
      case "broadcast": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        if (!teks) return balas("Contoh: .broadcast Pengumuman penting untuk semua chat!");
        const semuaChat = ambilSemuaChat();
        if (!semuaChat.length) return balas("Belum ada chat yang tercatat untuk dikirimi broadcast.");
        await balas(`📢 Mengirim ke ${semuaChat.length} chat (dijeda otomatis biar aman dari banned, mungkin makan waktu)...`);
        let sukses = 0;
        for (const tujuan of semuaChat) {
          try {
            await kirimAman(sock, tujuan, { text: `📢 *Pengumuman*\n\n${teks}` });
            sukses++;
          } catch (_) {}
        }
        return balas(`✅ Broadcast selesai: terkirim ke ${sukses}/${semuaChat.length} chat.`);
      }
      case "setbio": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        if (!teks) return balas("Contoh: .setbio Halo, ini bio baru!");
        await sock.updateProfileStatus(teks);
        return balas("✅ Bio berhasil diganti.");
      }
      case "block": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        const target = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!target) return balas("Tag kontak yang ingin diblokir.");
        await sock.updateBlockStatus(target, "block");
        return balas("✅ Kontak diblokir.");
      }
      case "unblock": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        const target = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!target) return balas("Tag kontak yang ingin dibuka blokirnya.");
        await sock.updateBlockStatus(target, "unblock");
        return balas("✅ Blokir dibuka.");
      }
      case "restart":
        if (!isOwner) return balas("Perintah ini khusus owner.");
        await balas("♻️ Memulai ulang bot...");
        process.exit(0);
        return;
      case "join": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        if (!teks) return balas("Contoh: .join https://chat.whatsapp.com/xxxx");
        try {
          const kodeInvite = teks.split("chat.whatsapp.com/")[1];
          await sock.groupAcceptInvite(kodeInvite);
          return balas("✅ Berhasil bergabung ke grup.");
        } catch { return balas("Gagal bergabung, link mungkin tidak valid."); }
      }

      // ==== OWNER: kontrol dashboard web ====
      case "dashboardon": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        updateSettings({ DASHBOARD_ENABLED: true });
        return balas("✅ Dashboard web diaktifkan lagi.");
      }
      case "dashboardoff": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        updateSettings({ DASHBOARD_ENABLED: false });
        return balas("🔒 Dashboard web dimatikan. Semua akses (termasuk yang sudah login) akan diblokir sampai kamu nyalakan lagi lewat .dashboardon");
      }
      case "setdashboarduser": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        if (!teks || teks.trim().length < 3) return balas("Contoh: .setdashboarduser namaBaru (minimal 3 karakter)");
        updateSettings({ DASHBOARD_USERNAME: teks.trim() });
        return balas(`✅ Username dashboard diganti jadi: ${teks.trim()}`);
      }
      case "setdashboardkey": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        if (!teks || teks.trim().length < 6) return balas("Contoh: .setdashboardkey KeyRahasiaKu123 (minimal 6 karakter)");
        updateSettings({ DASHBOARD_KEY: teks.trim() });
        return balas("✅ Key dashboard sudah diganti. Sesi yang sedang login TIDAK otomatis logout, tapi login baru wajib pakai key ini.");
      }
      case "loginnotif": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        if (teks === "on" || teks === "off") {
          updateSettings({ NOTIFY_ON_LOGIN: teks === "on" });
          return balas(`Notifikasi login dashboard: ${teks === "on" ? "diaktifkan ✅" : "dimatikan ❌"}`);
        }
        return balas("Gunakan .loginnotif on / .loginnotif off");
      }
      case "dashboardinfo": {
        if (!isOwner) return balas("Perintah ini khusus owner.");
        const s = getSettings();
        return balas(`🖥️ *Info Dashboard*\nStatus: ${s.DASHBOARD_ENABLED ? "Aktif ✅" : "Dimatikan 🔒"}\nUsername: ${s.DASHBOARD_USERNAME}\nKey: ${s.DASHBOARD_KEY}\nNotif login: ${s.NOTIFY_ON_LOGIN ? "Aktif" : "Nonaktif"}\n\n⚠️ Jangan forward pesan ini ke siapa pun.`);
      }

      default:
        return; // bukan perintah dikenal, diamkan
    }
  } catch (e) {
    console.error("Error saat memproses pesan:", e.message);
  }
}

module.exports = { tanganiPesan, DAFTAR_MENU };
